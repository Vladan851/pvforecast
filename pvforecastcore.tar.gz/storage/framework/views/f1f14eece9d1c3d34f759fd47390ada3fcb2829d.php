<html>
<head>
	<style>
	table, th, td {
		border: 1px solid black;
	}
	</style>
</head>
<body>
	<h1><?php echo e($loc); ?></h1>
	<h3><?php echo e($date1); ?></h3>
	<table style="width:100%">
	  <tr>
		<?php $__currentLoopData = $hours1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h1): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<th><?php echo e($h1); ?>-<?php echo e($h1+1); ?></th>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  </tr>
	  <tr>
		<?php $__currentLoopData = $pvs1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pv1): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<td><?php echo e($pv1/1000); ?></td>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  </tr>
	</table>
	<p>Ukupna proizvodnja za, <?php echo e($date1); ?>: <?php echo e($sum1); ?></p>
	<h3><?php echo e($date2); ?></h3>
	<table style="width:100%">
	  <tr>
		<?php $__currentLoopData = $hours2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h2): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<th><?php echo e($h2); ?>-<?php echo e($h2+1); ?></th>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  </tr>
	  <tr>
		<?php $__currentLoopData = $pvs2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pv2): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<td><?php echo e($pv2/1000); ?></td>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  </tr>
	</table>
	<p>Ukupna proizvodnja za, <?php echo e($date2); ?>: <?php echo e($sum2); ?></p>
	<h3><?php echo e($date3); ?></h3>
	<table style="width:100%">
	  <tr>
		<?php $__currentLoopData = $hours3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h3): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<th><?php echo e($h3); ?>-<?php echo e($h3+1); ?></th>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  </tr>
	  <tr>
		<?php $__currentLoopData = $pvs3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pv3): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<td><?php echo e($pv3/1000); ?></td>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  </tr>
	</table>
	<p>Ukupna proizvodnja za, <?php echo e($date3); ?>: <?php echo e($sum3); ?></p>
	<p><span>All prodaction values are in kW.</span></p>
</body>
</html>